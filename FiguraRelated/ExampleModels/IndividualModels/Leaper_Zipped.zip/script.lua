--visibility setup
vanilla_model.PLAYER:setVisible(false)
vanilla_model.ARMOR:setVisible(false)
vanilla_model.CAPE:setVisible(false)
vanilla_model.ELYTRA:setVisible(false)
models.model.root.Head.Head:setVisible(true)

--generate legs and set up
local ik = require("ZoidsIK")
local oldHitPositionFR = vec(0, 0, 0)
local oldHitPositionFL = vec(0, 0, 0)
local oldHitPositionBR = vec(0, 0, 0)
local oldHitPositionBL = vec(0, 0, 0)
local currentLegPositionFR = vec(0, 0, 0)
local currentLegPositionFL = vec(0, 0, 0)
local currentLegPositionBR = vec(0, 0, 0)
local currentLegPositionBL = vec(0, 0, 0)
local target = vectors.vec3(0, 0, 0)
local chainFrontRight = ik.new({
    models.chain.Skull.segment1,
    models.chain.Skull.segment1.segment2,
    models.chain.Skull.segment1.segment2.segment3,
    models.chain.Skull.segment1.segment2.segment3.segment4 },
  { 25, 25, 25, 25 },
  "FrontRightLegIK")
local chainFrontLeft = ik.new({
    models.chain2.Skull.segment1,
    models.chain2.Skull.segment1.segment2,
    models.chain2.Skull.segment1.segment2.segment3,
    models.chain2.Skull.segment1.segment2.segment3.segment4 },
  { 25, 25, 25, 25 },
  "FrontLeftLegIK")
local chainBackLeft = ik.new({
    models.chain3.Skull.segment1,
    models.chain3.Skull.segment1.segment2,
    models.chain3.Skull.segment1.segment2.segment3,
    models.chain3.Skull.segment1.segment2.segment3.segment4 },
  { 25, 25, 25, 25 },
  "BackLeftLegIK")
local chainBackRight = ik.new({
    models.chain4.Skull.segment1,
    models.chain4.Skull.segment1.segment2,
    models.chain4.Skull.segment1.segment2.segment3,
    models.chain4.Skull.segment1.segment2.segment3.segment4 },
  { 25, 25, 25, 25 },
  "BackRightLegIK")

--we dont want legs freezing if they hit something out of range,even though this shouldnt happen

chainFrontRight.autoPause = false
chainFrontLeft.autoPause = false
chainBackLeft.autoPause = false
chainBackRight.autoPause = false


local playerPosition
local hitpositionFrontRight = vec(0, 0, 0)
local hitpositionFrontLeft = vec(0, 0, 0)
local hitpositionBackRight = vec(0, 0, 0)
local hitpositionBackLeft = vec(0, 0, 0)
local playerHeadOriginRotY
local playerHeadOriginRotX

--otherwise legs take long to arrive at player position

function events.entity_init()
  playerPosition = player:getPos()
  hitpositionFrontRight = playerPosition
  hitpositionFrontLeft = playerPosition
  hitpositionBackRight = playerPosition
  hitpositionBackLeft = playerPosition
  oldHitPositionFR = playerPosition
  oldHitPositionFL = playerPosition
  oldHitPositionBR = playerPosition
  oldHitPositionBL = playerPosition
  currentLegPositionFR = playerPosition
  currentLegPositionFL = playerPosition
  currentLegPositionBR = playerPosition
  currentLegPositionBL = playerPosition
  playerHeadOriginRotX= vanilla_model.HEAD:getOriginRot().x
  playerHeadOriginRotY=vanilla_model.HEAD:getOriginRot().y
end

--math functions
local function cross_product(v1, v2)
  local result = vec(0, 0, 0)
  local x = v1[2] * v2[3] - v1[3] * v2[2]
  local y = v1[3] * v2[1] - v1[1] * v2[3]
  local z = v1[1] * v2[2] - v1[2] * v2[1]
  result = vec(x, y, z)
  return result
end

local square = math.sqrt;

local getDistance = function(a, b)
  local x, y, z = a.x - b.x, a.y - b.y, a.z - b.z;
  return square(x * x + y * y + z * z);
end;

--setup, dont touch
local distance
local velocity = 0
local maxDistance
local frontRightInAir = false
local frontLeftInAir = false
local backLeftInAir = false
local backRightInAir = false
local soundPlayedFR=false
local soundPlayedFL=false
local soundPlayedBR=false
local soundPlayedBL=false
local ceilingFR=false
local ceilingBL=false
local ceilingFL=false
local ceilingBR=false
local ceilingAllowed=true
local personalSoundsVolume=0.7
local globalSoundsVolume=0.25
local attackEffect=200
local legQuality=2




local mainPage = action_wheel:newPage("Main Page")

action_wheel:setPage(mainPage)


--#region ActionWheel Actions in here
local personalSoundAdjustment = mainPage:newAction()
    :title("Adjust personal leg footstep sound volume\nCurrent volume: "..tostring( globalSoundsVolume).."\nDefault: 0.7")
    :item("minecraft:white_wool")
    :hoverColor(125, 125, 125)
    :setOnScroll(function(dir)
        if (dir > 0 and personalSoundsVolume<1) then
          personalSoundsVolume= personalSoundsVolume+0.05
        elseif (dir < 1 and personalSoundsVolume>0.05) then
          personalSoundsVolume=personalSoundsVolume-0.05
        elseif (dir < 1) then
          personalSoundsVolume=0
    end
  end)
  function pings.globalSoundAdjustmentPing(dir)
    if (dir > 0 and globalSoundsVolume<1) then
          globalSoundsVolume= globalSoundsVolume+0.05
        elseif (dir < 1 and globalSoundsVolume>0.06) then
          globalSoundsVolume=globalSoundsVolume-0.05
        elseif (dir < 1) then
          globalSoundsVolume=0
    end
  end

  local globalSoundAdjustment = mainPage:newAction()
    :title("Adjust global (other people's) leg footstep sound volume\nCurrent volume: "..tostring( globalSoundsVolume).."\nDefault: 0.25")
    :item("minecraft:white_wool")
    :hoverColor(125, 125, 125)
    :setOnScroll(pings.globalSoundAdjustmentPing)

  function pings.playLeaperSpotSoundping()
    sounds:playSound("Leaper_spot.mono.opt",playerPosition+vec(0,2,0),1,1,false)
  end

  local playLeaperSpotSound = mainPage:newAction()
  :title("Play the sound the leaper does when spotting someone.")
  :item("goat_horn")
  :hoverColor(125,125,125)
  :setOnLeftClick(pings.playLeaperSpotSoundping)

  function pings.playLeaperAttackSoundping()
  attackEffect=0
  sounds:playSound("Leaper_explosion2.mono.opt",playerPosition+vec(0,2,0),0.7,1,false)
  end

  local playAttackSpotSound = mainPage:newAction()
  :title("Simulate a leaper attack.")
  :item("netherite_sword")
  :hoverColor(125,125,125)
  :setOnLeftClick(pings.playLeaperAttackSoundping)
  
  function pings.allowCeilingTogglePing()
    if (ceilingAllowed) then
      ceilingAllowed=false
    else
      ceilingAllowed=true
    end
  end

  local allowCeilingToggle = mainPage:newAction()
  :title("Toggle wether or not the legs are allowed to attach to the ceiling if possible.\nCurrent setting is:"..tostring(ceilingAllowed).."\nDefault is: true")
  :item("polished_deepslate")
  :hoverColor(125,125,125)
  :setOnLeftClick(pings.allowCeilingTogglePing)

function pings.legQualityPing(dir)
    if (dir > 0 and legQuality<20) then
          legQuality=legQuality+1
        elseif (dir < 1 and legQuality>1) then
          legQuality=legQuality-1
    end
  end

  local legMovementQuality = mainPage:newAction()
    :title("Adjust how high the quality of the leg Inverse Kinematics are. Current Value: "..tostring( legQuality).."\nDefault: 2\nUpper/Lower bounds are 20 and 1 respectively. Increasing the quality HEAVILY increases computational cost.\nNot recommended to increase over 2 if you want this avatar to run on default permissions.")
    :item("minecraft:end_rod")
    :hoverColor(125, 125, 125)
    :setOnScroll(pings.legQualityPing)
--#endregion


--leg visibility
if host:isHost() then
  function events.tick()
    if renderer:isFirstPerson() then
      chainFrontRight:setVisibleParts(false)
      chainFrontLeft:setVisibleParts(false)
      chainBackRight:setVisibleParts(false)
      chainBackLeft:setVisibleParts(false)
    else
      chainFrontRight:setVisibleParts(true)
      chainFrontLeft:setVisibleParts(true)
      chainBackRight:setVisibleParts(true)
      chainBackLeft:setVisibleParts(true)
    end
  end
end

function events.tick()
  playerHeadOriginRotX= vanilla_model.HEAD:getOriginRot().x
  playerHeadOriginRotY=vanilla_model.HEAD:getOriginRot().y
  --update position every tick
  playerPosition = player:getPos()
  velocity = player:getVelocity()
  legMovementQuality:title("Adjust how high the quality of the leg Inverse Kinematics are. \nCurrent Value: "..tostring( legQuality).."\nDefault: 2\nUpper/Lower bounds are 20 and 1 respectively. Increasing the quality HEAVILY increases computational cost.\nNot recommended to increase over 2 if you want this avatar to run on default permissions.\nNot much noticeable effect over 5.")
personalSoundAdjustment:title("Adjust personal leg footstep sound volume\nCurrent volume: "..tostring( personalSoundsVolume).."\nDefault: 0.7")
globalSoundAdjustment:title("Adjust global (other people's) leg footstep sound volume\nCurrent volume: "..tostring( globalSoundsVolume).."\nDefault: 0.25\nPersonal note: Please dont be obnoxious and turn this up higher than necessary.\n0.25 usually works best for everyone.")
allowCeilingToggle:title("Toggle wether or not the legs are allowed to attach to the ceiling if possible.\nCurrent setting is:"..tostring(ceilingAllowed).."\nDefault is: true\nNote: For some reason,disabling this causes the legs to break animation in some scenarios (Should not crash the avatar though). Recommended to keep enabled for this reason.")
  
--lighting
  models.model.root.DisplayHead:setPos(playerPosition)
  models:setLight(world.getLightLevel(playerPosition))
  chainFrontRight:setChainLight(world.getLightLevel(playerPosition))
  chainFrontLeft:setChainLight(world.getLightLevel(playerPosition))
  chainBackRight:setChainLight(world.getLightLevel(playerPosition))
  chainBackLeft:setChainLight(world.getLightLevel(playerPosition))
  
  if velocity == vec(0, 0, 0) then
    maxDistance = 2
  else
    maxDistance = 3
  end
if (attackEffect <100) then
if (attackEffect<10) then
  particles:newParticle("minecraft:flame",playerPosition+vec(math.random(-2,2),math.random(-2,2)+1.5,math.random(-2,2)))  
  attackEffect=attackEffect+1
  elseif(attackEffect==50) then
particles:newParticle("minecraft:explosion_emitter",playerPosition)

attackEffect=attackEffect+1
  elseif (attackEffect<30) then
  particles:newParticle("minecraft:flame",playerPosition+vec(math.random(-2,2),math.random(-2,2)+1.5,math.random(-2,2)))
  particles:newParticle("minecraft:flame",playerPosition+vec(math.random(-2,2),math.random(-2,2)+1.5,math.random(-2,2)))
  attackEffect=attackEffect+1
  
elseif (attackEffect<50) then
  particles:newParticle("minecraft:flame",playerPosition+vec(math.random(-2,2),math.random(-2,2)+1.5,math.random(-2,2)))
  particles:newParticle("minecraft:flame",playerPosition+vec(math.random(-2,2),math.random(-2,2)+1.5,math.random(-2,2)))
  particles:newParticle("minecraft:flame",playerPosition+vec(math.random(-2,2),math.random(-2,2)+1.5,math.random(-2,2)))
  
  attackEffect=attackEffect+1
elseif (attackEffect<70 and attackEffect >55) then
  particles:newParticle("minecraft:campfire_signal_smoke",playerPosition+vec(math.random(-2,2),math.random(-2,2)+1.5,math.random(-2,2))):setScale(10)
  particles:newParticle("minecraft:campfire_signal_smoke",playerPosition+vec(math.random(-2,2),math.random(-2,2)+1.5,math.random(-2,2))):setScale(10)
  attackEffect=attackEffect+1
  elseif (attackEffect<90 and attackEffect>70) then
  particles:newParticle("minecraft:campfire_signal_smoke",playerPosition+vec(math.random(-8,8),math.random(-3,8)+1.5,math.random(-8,8))):setScale(10)
  particles:newParticle("minecraft:campfire_signal_smoke",playerPosition+vec(math.random(-8,8),math.random(-3,8)+1.5,math.random(-8,8))):setScale(10)


  attackEffect=attackEffect+1
  elseif(attackEffect <200) then
    attackEffect=attackEffect+1
end 
end

  local tempHitposition
  --raycasting target blocks for all 4 legs

  -- pls dont judge i tried to make a function for this but it broke and i really dont want to touch this anymore :broken_heart:

if (ceilingAllowed==true) then
  if (math.abs(player:getLookDir().x) >0.4 or math.abs(player:getLookDir().z) >0.4 ) then
  _, tempHitposition, _ = raycast:block(
    playerPosition + vec(0, 1, 0),
    playerPosition + vec(0, player:getEyeHeight(), 0) +
    cross_product(player:getLookDir(),
      models.model.root.Head.Head:partToWorldMatrix():applyDir(0, 90, 0)) * vec(0.6, 1, 0.6) +
    player:getLookDir() * vec(2.5, 0 , 2.5))
  _, tempHitposition, _ = raycast:block(
    tempHitposition,
    tempHitposition + vec(0, 7, 0))
  hitpositionFrontRight = tempHitposition

  elseif (player:getLookDir().x <0.4 and player:getRot().x >-60 or player:getLookDir().z <0.4 and player:getRot().x >-60) then
    _, tempHitposition, _ = raycast:block(
    playerPosition + vec(0, 1, 0),
    playerPosition + vec(0, player:getEyeHeight(), 0) +
    cross_product(player:getLookDir(),
      models.model.root.Head.Head:partToWorldMatrix():applyDir(0, 90, 0)) * vec(0.6, 1, 0.6) +
    models.model.root.Head.Head:partToWorldMatrix():applyDir(0, 22, 0) * vec(2.5, 0 , 2.5))
  _, tempHitposition, _ = raycast:block(
    tempHitposition,
    tempHitposition + vec(0, 7, 0))
  hitpositionFrontRight = tempHitposition
  else

    _, tempHitposition, _ = raycast:block(
    playerPosition + vec(0, 1, 0),
    playerPosition + vec(0, player:getEyeHeight(), 0) +
    cross_product(player:getLookDir(),
      models.model.root.Head.Head:partToWorldMatrix():applyDir(0, 90, 0)) * vec(0.6, 1, 0.6) +
    models.model.root.Head.Head:partToWorldMatrix():applyDir(-0, 22, -0) * vec(-2.5, 0 , -2.5))
  _, tempHitposition, _ = raycast:block(
    tempHitposition,
    tempHitposition + vec(0, 7, 0))
  hitpositionFrontRight = tempHitposition
  end
  ceilingFR=true
end
if (math.abs(hitpositionFrontRight.y- playerPosition.y) <2.5 or math.abs(hitpositionFrontRight.y- playerPosition.y)>6)then 
  ceilingFR=false
   if (math.abs(player:getLookDir().x) >0.4 or math.abs(player:getLookDir().z) >0.4 ) then
  _, tempHitposition, _ = raycast:block(
    playerPosition + vec(0, 1, 0),
    playerPosition + vec(0, player:getEyeHeight(), 0) +
    cross_product(player:getLookDir(),
      models.model.root.Head.Head:partToWorldMatrix():applyDir(0, 90, 0)) * vec(0.6, 1, 0.6) +
    player:getLookDir() * vec(2.5, 0 , 2.5))
  _, tempHitposition, _ = raycast:block(
    tempHitposition,
    tempHitposition - vec(0, 7, 0))
  hitpositionFrontRight = tempHitposition

  elseif (player:getLookDir().x <0.4 and player:getRot().x >-60 or player:getLookDir().z <0.4 and player:getRot().x >-60) then
    _, tempHitposition, _ = raycast:block(
    playerPosition + vec(0, 1, 0),
    playerPosition + vec(0, player:getEyeHeight(), 0) +
    cross_product(player:getLookDir(),
      models.model.root.Head.Head:partToWorldMatrix():applyDir(0, 90, 0)) * vec(0.6, 1, 0.6) +
    models.model.root.Head.Head:partToWorldMatrix():applyDir(0, 22, 0) * vec(2.5, 0 , 2.5))
  _, tempHitposition, _ = raycast:block(
    tempHitposition,
    tempHitposition - vec(0, 7, 0))
  hitpositionFrontRight = tempHitposition
  else

    _, tempHitposition, _ = raycast:block(
    playerPosition + vec(0, 1, 0),
    playerPosition + vec(0, player:getEyeHeight(), 0) +
    cross_product(player:getLookDir(),
      models.model.root.Head.Head:partToWorldMatrix():applyDir(0, 90, 0)) * vec(0.6, 1, 0.6) +
    models.model.root.Head.Head:partToWorldMatrix():applyDir(-0, 22, -0) * vec(-2.5, 0 , -2.5))
  _, tempHitposition, _ = raycast:block(
    tempHitposition,
    tempHitposition - vec(0, 7, 0))
  hitpositionFrontRight = tempHitposition
  end
end
if (ceilingAllowed==true) then
  if (math.abs(player:getLookDir().x) >0.4 or math.abs(player:getLookDir().z) >0.4 ) then
  _, tempHitposition, _ = raycast:block(
    playerPosition + vec(0, 1, 0),
    playerPosition + vec(0, player:getEyeHeight(), 0) +
    cross_product(player:getLookDir(),
      models.model.root.Head.Head:partToWorldMatrix():applyDir(0, 90, 0)) * vec(0.6, 1, 0.6) +
    player:getLookDir() * vec(-2.5, 0, -2.5))
  _, tempHitposition, _ = raycast:block(
    tempHitposition,
    tempHitposition + vec(0, 7, 0))
  hitpositionBackRight = tempHitposition

  elseif (player:getLookDir().x <0.4 and player:getRot().x >-60 or player:getLookDir().z <0.4 and player:getRot().x >-60) then
    _, tempHitposition, _ = raycast:block(
    playerPosition + vec(0, 1, 0),
    playerPosition + vec(0, player:getEyeHeight(), 0) +
    cross_product(player:getLookDir(),
      models.model.root.Head.Head:partToWorldMatrix():applyDir(0, 90, 0)) * vec(0.6, 1, 0.6) +
    models.model.root.Head.Head:partToWorldMatrix():applyDir(0, 22, 0) * vec(-2.5, 0 , -2.5))
  _, tempHitposition, _ = raycast:block(
    tempHitposition,
    tempHitposition + vec(0, 7, 0))
  hitpositionBackRight = tempHitposition
  else

    _, tempHitposition, _ = raycast:block(
    playerPosition + vec(0, 1, 0),
    playerPosition + vec(0, player:getEyeHeight(), 0) +
    cross_product(player:getLookDir(),
      models.model.root.Head.Head:partToWorldMatrix():applyDir(0, 90, 0)) * vec(0.6, 1, 0.6) +
    models.model.root.Head.Head:partToWorldMatrix():applyDir(-0, 22, -0) * vec(2.5, 0 , 2.5))
  _, tempHitposition, _ = raycast:block(
    tempHitposition,
    tempHitposition + vec(0, 7, 0))
  hitpositionBackRight = tempHitposition
  end
  ceilingBR=true
end
  if (math.abs(hitpositionBackRight.y- playerPosition.y) <2.5 or math.abs(hitpositionBackRight.y- playerPosition.y)>6)then 
    ceilingBR=false
if (math.abs(player:getLookDir().x) >0.4 or math.abs(player:getLookDir().z) >0.4 ) then
  _, tempHitposition, _ = raycast:block(
    playerPosition + vec(0, 1, 0),
    playerPosition + vec(0, player:getEyeHeight(), 0) +
    cross_product(player:getLookDir(),
      models.model.root.Head.Head:partToWorldMatrix():applyDir(0, 90, 0)) * vec(0.6, 1, 0.6) +
    player:getLookDir() * vec(-2.5, 0, -2.5))
  _, tempHitposition, _ = raycast:block(
    tempHitposition,
    tempHitposition - vec(0, 7, 0))
  hitpositionBackRight = tempHitposition

  elseif (player:getLookDir().x <0.4 and player:getRot().x >-60 or player:getLookDir().z <0.4 and player:getRot().x >-60) then
    _, tempHitposition, _ = raycast:block(
    playerPosition + vec(0, 1, 0),
    playerPosition + vec(0, player:getEyeHeight(), 0) +
    cross_product(player:getLookDir(),
      models.model.root.Head.Head:partToWorldMatrix():applyDir(0, 90, 0)) * vec(0.6, 1, 0.6) +
    models.model.root.Head.Head:partToWorldMatrix():applyDir(0, 22, 0) * vec(-2.5, 0 , -2.5))
  _, tempHitposition, _ = raycast:block(
    tempHitposition,
    tempHitposition - vec(0, 7, 0))
  hitpositionBackRight = tempHitposition
  else

    _, tempHitposition, _ = raycast:block(
    playerPosition + vec(0, 1, 0),
    playerPosition + vec(0, player:getEyeHeight(), 0) +
    cross_product(player:getLookDir(),
      models.model.root.Head.Head:partToWorldMatrix():applyDir(0, 90, 0)) * vec(0.6, 1, 0.6) +
    models.model.root.Head.Head:partToWorldMatrix():applyDir(-0, 22, -0) * vec(2.5, 0 , 2.5))
  _, tempHitposition, _ = raycast:block(
    tempHitposition,
    tempHitposition - vec(0, 7, 0))
  hitpositionBackRight = tempHitposition
  end
end
  if (ceilingAllowed==true) then
  if (math.abs(player:getLookDir().x) >0.4 or math.abs(player:getLookDir().z) >0.4 ) then
  _, tempHitposition, _ = raycast:block(
    playerPosition + vec(0, 1, 0),
    playerPosition + vec(0, player:getEyeHeight(), 0) +
    cross_product(player:getLookDir(),
      models.model.root.Head.Head:partToWorldMatrix():applyDir(0, 90, 0)) * vec(-0.6, 1, -0.6) +
    player:getLookDir() * vec(-2.5, 0, -2.5))
  _, tempHitposition, _ = raycast:block(
    tempHitposition,
    tempHitposition + vec(0, 7, 0))
  hitpositionBackLeft = tempHitposition

elseif (player:getLookDir().x <0.4 and player:getRot().x >-60 or player:getLookDir().z <0.4 and player:getRot().x >-60) then
  _, tempHitposition, _ = raycast:block(
    playerPosition + vec(0, 1, 0),
    playerPosition + vec(0, player:getEyeHeight(), 0) +
    cross_product(player:getLookDir(),
      models.model.root.Head.Head:partToWorldMatrix():applyDir(0, 90, 0)) * vec(-0.6, 1, -0.6) +
    models.model.root.Head.Head:partToWorldMatrix():applyDir(-0, 22, -0) * vec(-2.5, 0 , -2.5))
  _, tempHitposition, _ = raycast:block(
    tempHitposition,
    tempHitposition + vec(0, 7, 0))
  hitpositionBackLeft = tempHitposition
  else
    
    _, tempHitposition, _ = raycast:block(
    playerPosition + vec(0, 1, 0),
    playerPosition + vec(0, player:getEyeHeight(), 0) +
    cross_product(player:getLookDir(),
      models.model.root.Head.Head:partToWorldMatrix():applyDir(0, 90, 0)) * vec(-0.6, 1, -0.6) +
    models.model.root.Head.Head:partToWorldMatrix():applyDir(-0, 22, -0) * vec(2.5, 0 , 2.5))
  _, tempHitposition, _ = raycast:block(
    tempHitposition,
    tempHitposition + vec(0, 7, 0))
  hitpositionBackLeft = tempHitposition
  end
  ceilingBL=true
end
  if (math.abs(hitpositionBackLeft.y- playerPosition.y) <2.5 or math.abs(hitpositionBackLeft.y- playerPosition.y)>6)then 
    ceilingBL=false
  if (math.abs(player:getLookDir().x) >0.4 or math.abs(player:getLookDir().z) >0.4 ) then
  _, tempHitposition, _ = raycast:block(
    playerPosition + vec(0, 1, 0),
    playerPosition + vec(0, player:getEyeHeight(), 0) +
    cross_product(player:getLookDir(),
      models.model.root.Head.Head:partToWorldMatrix():applyDir(0, 90, 0)) * vec(-0.6, 1, -0.6) +
    player:getLookDir() * vec(-2.5, 0, -2.5))
  _, tempHitposition, _ = raycast:block(
    tempHitposition,
    tempHitposition - vec(0, 7, 0))
  hitpositionBackLeft = tempHitposition

elseif (player:getLookDir().x <0.4 and player:getRot().x >-60 or player:getLookDir().z <0.4 and player:getRot().x >-60) then
  _, tempHitposition, _ = raycast:block(
    playerPosition + vec(0, 1, 0),
    playerPosition + vec(0, player:getEyeHeight(), 0) +
    cross_product(player:getLookDir(),
      models.model.root.Head.Head:partToWorldMatrix():applyDir(0, 90, 0)) * vec(-0.6, 1, -0.6) +
    models.model.root.Head.Head:partToWorldMatrix():applyDir(-0, 22, -0) * vec(-2.5, 0 , -2.5))
  _, tempHitposition, _ = raycast:block(
    tempHitposition,
    tempHitposition - vec(0, 7, 0))
  hitpositionBackLeft = tempHitposition
  else
    
    _, tempHitposition, _ = raycast:block(
    playerPosition + vec(0, 1, 0),
    playerPosition + vec(0, player:getEyeHeight(), 0) +
    cross_product(player:getLookDir(),
      models.model.root.Head.Head:partToWorldMatrix():applyDir(0, 90, 0)) * vec(-0.6, 1, -0.6) +
    models.model.root.Head.Head:partToWorldMatrix():applyDir(-0, 22, -0) * vec(2.5, 0 , 2.5))
  _, tempHitposition, _ = raycast:block(
    tempHitposition,
    tempHitposition - vec(0, 7, 0))
  hitpositionBackLeft = tempHitposition
  end

end

if (ceilingAllowed==true) then
  if (math.abs(player:getLookDir().x) >0.3 or math.abs(player:getLookDir().z) >0.3 ) then
  _, tempHitposition, _ = raycast:block(
    playerPosition + vec(0, 1, 0),
    playerPosition + vec(0, player:getEyeHeight(), 0) +
    cross_product(player:getLookDir(),
      models.model.root.Head.Head:partToWorldMatrix():applyDir(0, 90, 0)) * vec(-0.6, 1, -0.6) +
    player:getLookDir() * vec(2.5, 0, 2.5))
  _, tempHitposition, _ = raycast:block(
    tempHitposition,
    tempHitposition + vec(0, 7, 0))
  hitpositionFrontLeft = tempHitposition

elseif (player:getLookDir().x <0.5 and player:getRot().x >-60 or player:getLookDir().z <0.5 and player:getRot().x >-60) then
  _, tempHitposition, _ = raycast:block(
    playerPosition + vec(0, 1, 0),
    playerPosition + vec(0, player:getEyeHeight(), 0) +
    cross_product(player:getLookDir(),
      models.model.root.Head.Head:partToWorldMatrix():applyDir(0, 90, 0)) * vec(-0.6, 1, -0.6) +
    models.model.root.Head.Head:partToWorldMatrix():applyDir(-0, 22, -0) * vec(2.5, 0 , 2.5))
  _, tempHitposition, _ = raycast:block(
    tempHitposition,
    tempHitposition + vec(0, 7, 0))
  hitpositionFrontLeft = tempHitposition
  else

    _, tempHitposition, _ = raycast:block(
    playerPosition + vec(0, 1, 0),
    playerPosition + vec(0, player:getEyeHeight(), 0) +
    cross_product(player:getLookDir(),
      models.model.root.Head.Head:partToWorldMatrix():applyDir(0, 90, 0)) * vec(-0.6, 1, -0.6) +
    models.model.root.Head.Head:partToWorldMatrix():applyDir(-0, 22, -0) * vec(-2.5, 0 , -2.5))
  _, tempHitposition, _ = raycast:block(
    tempHitposition,
    tempHitposition + vec(0, 7, 0))
  hitpositionFrontLeft = tempHitposition
  end
  ceilingFL=true
end
  if (math.abs(hitpositionFrontLeft.y- playerPosition.y) <2.5 or math.abs(hitpositionFrontLeft.y- playerPosition.y)>6)then 
    ceilingFL=false
  if (math.abs(player:getLookDir().x) >0.3 or math.abs(player:getLookDir().z) >0.3 ) then
  _, tempHitposition, _ = raycast:block(
    playerPosition + vec(0, 1, 0),
    playerPosition + vec(0, player:getEyeHeight(), 0) +
    cross_product(player:getLookDir(),
      models.model.root.Head.Head:partToWorldMatrix():applyDir(0, 90, 0)) * vec(-0.6, 1, -0.6) +
    player:getLookDir() * vec(2.5, 0, 2.5))
  _, tempHitposition, _ = raycast:block(
    tempHitposition,
    tempHitposition - vec(0, 7, 0))
  hitpositionFrontLeft = tempHitposition

elseif (player:getLookDir().x <0.5 and player:getRot().x >-60 or player:getLookDir().z <0.5 and player:getRot().x >-60) then
  _, tempHitposition, _ = raycast:block(
    playerPosition + vec(0, 1, 0),
    playerPosition + vec(0, player:getEyeHeight(), 0) +
    cross_product(player:getLookDir(),
      models.model.root.Head.Head:partToWorldMatrix():applyDir(0, 90, 0)) * vec(-0.6, 1, -0.6) +
    models.model.root.Head.Head:partToWorldMatrix():applyDir(-0, 22, -0) * vec(2.5, 0 , 2.5))
  _, tempHitposition, _ = raycast:block(
    tempHitposition,
    tempHitposition - vec(0, 7, 0))
  hitpositionFrontLeft = tempHitposition
  else

    _, tempHitposition, _ = raycast:block(
    playerPosition + vec(0, 1, 0),
    playerPosition + vec(0, player:getEyeHeight(), 0) +
    cross_product(player:getLookDir(),
      models.model.root.Head.Head:partToWorldMatrix():applyDir(0, 90, 0)) * vec(-0.6, 1, -0.6) +
    models.model.root.Head.Head:partToWorldMatrix():applyDir(-0, 22, -0) * vec(-2.5, 0 , -2.5))
  _, tempHitposition, _ = raycast:block(
    tempHitposition,
    tempHitposition - vec(0, 7, 0))
  hitpositionFrontLeft = tempHitposition
  end
end

--checking if a leg is allowed to move

  distance = getDistance(hitpositionFrontLeft, oldHitPositionFL)
if (chainFrontLeft:isInReach(currentLegPositionFL) == false) then
    backRightInAir,backLeftInAir,frontRightInAir = false,false,false
  end
  if (distance > maxDistance or math.abs(hitpositionFrontLeft.y - oldHitPositionFL.y) > 0.5) then
    if (backLeftInAir == false and frontRightInAir == false and backRightInAir == false or velocity == vec(0, 0, 0)) then
      frontLeftInAir = true
      oldHitPositionFL = hitpositionFrontLeft
    end
  end

  distance = getDistance(hitpositionFrontRight, oldHitPositionFR)
  if (chainFrontRight:isInReach(currentLegPositionFR) == false) then
     backRightInAir,backLeftInAir,frontLeftInAir = false,false,false
  end
  if (distance > maxDistance or math.abs(hitpositionFrontRight.y - oldHitPositionFR.y) > 0.5) then
    if (backRightInAir == false and frontLeftInAir == false and backLeftInAir == false or velocity == vec(0, 0, 0)) then
      frontRightInAir = true
      oldHitPositionFR = hitpositionFrontRight
    end
  end

  distance = getDistance(hitpositionBackLeft, oldHitPositionBL)
    if (chainBackLeft:isInReach(currentLegPositionBL) == false) then
    backRightInAir,frontRightInAir,frontLeftInAir = false,false,false
  end
  if (distance > maxDistance or math.abs(hitpositionBackLeft.y - oldHitPositionBL.y) > 0.5) then
    
    if (backRightInAir == false and frontLeftInAir == false and frontRightInAir == false or velocity == vec(0, 0, 0)) then
      backLeftInAir = true
      oldHitPositionBL = hitpositionBackLeft
    end
  end

  distance = getDistance(hitpositionBackRight, oldHitPositionBR)
    if (chainBackRight:isInReach(currentLegPositionBR) == false) then
    frontRightInAir,backLeftInAir,frontLeftInAir = false,false,false
  end
  if (distance > maxDistance or math.abs(hitpositionBackRight.y - oldHitPositionBR.y) > 0.5) then
    
    if (frontRightInAir == false and backLeftInAir == false and frontLeftInAir == false or velocity == vec(0, 0, 0)) then
      backRightInAir = true
      oldHitPositionBR = hitpositionBackRight
    end
  end

  --movement smoothing
  currentLegPositionFL = math.lerp(currentLegPositionFL, oldHitPositionFL, 0.35)
  currentLegPositionFR = math.lerp(currentLegPositionFR, oldHitPositionFR, 0.35)
  currentLegPositionBR = math.lerp(currentLegPositionBR, oldHitPositionBR, 0.35)
  currentLegPositionBL = math.lerp(currentLegPositionBL, oldHitPositionBL, 0.35)

  --actually moving the legs using solve from the IK library with some additional flair + footstep sounds
  local straighteningVector
  local stepMult
  if (ceilingFR==false) then straighteningVector= vec(0,7,0) stepMult=1.1
  else
    straighteningVector=vec(0,-7,0)
    stepMult=-1.1
  end
  distance = getDistance(currentLegPositionFR, oldHitPositionFR)
  if distance > 0.1 and distance < 2 then
    soundPlayedFR=false
    chainFrontRight:solve(playerPosition + vectors.vec3(0, 1.5, 0), currentLegPositionFR + straighteningVector, 1)
    chainFrontRight:solve(playerPosition + vectors.vec3(0, 1.5, 0),
      currentLegPositionFR + vec(0,stepMult * distance, 0), legQuality)
  else
    frontRightInAir = false
    if (soundPlayedFR== false) then
      if host:isHost() then
    sounds:playSound("block.netherite_block.step",currentLegPositionFR,personalSoundsVolume,1,false)
    soundPlayedFR=true
      else
    sounds:playSound("block.netherite_block.step",currentLegPositionFR,globalSoundsVolume,1,false)
    soundPlayedFR=true
    end
    end
    chainFrontRight:solve(playerPosition + vectors.vec3(0, 1.5, 0), currentLegPositionFR + straighteningVector, 1)
    chainFrontRight:solve(playerPosition + vectors.vec3(0, 1.5, 0), currentLegPositionFR, legQuality)
  end
if (ceilingFL==false) then straighteningVector= vec(0,7,0) stepMult=1.1
  else
    straighteningVector=vec(0,-7,0)
    stepMult=-1.1
  end
  distance = getDistance(currentLegPositionFL, oldHitPositionFL)
  if distance > 0.1 and distance < 2 then
    soundPlayedFL=false
    chainFrontLeft:solve(playerPosition + vectors.vec3(0, 1.5, 0), currentLegPositionFL + straighteningVector,1)
    chainFrontLeft:solve(playerPosition + vectors.vec3(0, 1.5, 0),
      currentLegPositionFL + vec(0, stepMult * distance, 0), legQuality)
  else
    if (soundPlayedFL== false) then
    if host:isHost() then
    sounds:playSound("block.netherite_block.step",currentLegPositionFL,personalSoundsVolume,1,false)
    soundPlayedFL=true
      else
    sounds:playSound("block.netherite_block.step",currentLegPositionFL,globalSoundsVolume,1,false)
    soundPlayedFL=true
    
    end
  end
    chainFrontLeft:solve(playerPosition + vectors.vec3(0, 1.5, 0), currentLegPositionFL + straighteningVector,1)
    chainFrontLeft:solve(playerPosition + vectors.vec3(0, 1.5, 0), currentLegPositionFL, legQuality)
    frontLeftInAir = false
  end
  if (ceilingBR==false) then straighteningVector= vec(0,7,0) stepMult=1.1
  else
    straighteningVector=vec(0,-7,0)
    stepMult=-1.1
  end
  distance = getDistance(currentLegPositionBR, oldHitPositionBR)
  if distance > 0.1 and distance < 2 then
        soundPlayedBR=false
    chainBackRight:solve(playerPosition + vectors.vec3(0, 1.5, 0), currentLegPositionBR + straighteningVector,1)
    chainBackRight:solve(playerPosition + vectors.vec3(0, 1.5, 0),
      currentLegPositionBR + vec(0, stepMult * distance, 0), legQuality)
  
  else
    if (soundPlayedBR== false) then
    if host:isHost() then
    sounds:playSound("block.netherite_block.step",currentLegPositionBR,personalSoundsVolume,1,false)
    soundPlayedBR=true
      else
    sounds:playSound("block.netherite_block.step",currentLegPositionBR,globalSoundsVolume,1,false)
    soundPlayedBR=true
    end
    end
    backRightInAir = false
    chainBackRight:solve(playerPosition + vectors.vec3(0, 1.5, 0), currentLegPositionBR + straighteningVector,1)
    chainBackRight:solve(playerPosition + vectors.vec3(0, 1.5, 0), currentLegPositionBR, legQuality)
  end
if (ceilingBL==false) then straighteningVector= vec(0,7,0) stepMult=1.1
  else
    straighteningVector=vec(0,-7,0)
    stepMult=-1.1
  end
  distance = getDistance(currentLegPositionBL, oldHitPositionBL)
  if distance > 0.1 and distance < 2 then
    soundPlayedBL=false
    chainBackLeft:solve(playerPosition + vectors.vec3(0, 1.5, 0), currentLegPositionBL + straighteningVector,1)
    chainBackLeft:solve(playerPosition + vectors.vec3(0, 1.5, 0),
      currentLegPositionBL + vec(0, stepMult * distance, 0), legQuality)
  else
    if (soundPlayedBL== false) then
    if host:isHost() then
    sounds:playSound("block.netherite_block.step",currentLegPositionBL,personalSoundsVolume,1,false)
    soundPlayedBL=true
      else
    sounds:playSound("block.netherite_block.step",currentLegPositionBL,globalSoundsVolume,1,false)
    soundPlayedBL=true
    end
    end
    backLeftInAir = false
    chainBackLeft:solve(playerPosition + vectors.vec3(0, 1.5, 0), currentLegPositionBL + straighteningVector,1)
    chainBackLeft:solve(playerPosition + vectors.vec3(0, 1.5, 0), currentLegPositionBL, legQuality)
  end


  --making the head rotate and bounce up and down depending on where the legs are
  
  models.model.root.DisplayHead:setPos(0,
    ((currentLegPositionBL.y - models.model.root.DisplayHead:getPos().y) * 1.2 + (currentLegPositionBR.y - models.model.root.DisplayHead:getPos().y) * 1.2 + (currentLegPositionFL.y - models.model.root.DisplayHead:getPos().y) * 1.2 + (currentLegPositionFR.y - models.model.root.DisplayHead:getPos().y) * 1.2) /
    4, 0)
  if (playerHeadOriginRotX <= 30 and playerHeadOriginRotX > 0) then
    models.model.root.DisplayHead:setRot(playerHeadOriginRotX,
      playerHeadOriginRotY)
  else
    if (playerHeadOriginRotX >= -30 and playerHeadOriginRotX <= 0) then
      models.model.root.DisplayHead:setRot(playerHeadOriginRotX,
        playerHeadOriginRotY)
    else
      if (playerHeadOriginRotX <= -30) then
        models.model.root.DisplayHead:setRot(-30, playerHeadOriginRotY)
      else
        models.model.root.DisplayHead:setRot(30, playerHeadOriginRotY)
      end
    end
  end
end

