
UNSURE ABOUT SCRIPTS? UNSURE ABOUT WHAT THEY DO AND HOW THEY WORK? NEED A VISUAL EXAMPLE?
	
	THIS MODEL IS HERE TO HELP!

In this model, I will demonstrate how you can use a variety of the scripts included in my UsefulScripts zip.
I will show how the animations for them work, how the scripts for them work, etc.
This model on its own should hopefully be able to answer most of your questions, or at least provide an example for you to utilise in your own model.
I am going to make this model bizarre and patchwork-ey in order to get as many examples of model features included as possible.


NOTE #1: if you're using EZAnims + GSAnimblend **AND** you want to use the dynamic_speed script for custom walk/movement animations, a section of code will need to be removed from the dynamic_speed script. This chunk of code will be removed pre-emptively from this example model, but will be left alone in the UsefulScripts.zip.

NOTE #2: if your model name is NOT 'model' and you intend to use the dynamic_speed script, you must go into the dynamic_speed script and replace 'model' with your modelname on line 25!

NOTE #3: PLEASE DON'T DISTRIBUTE THIS MODEL ANYWHERE OUTSIDE OF ARTHOUSE. I PUT QUITE A LOT OF EFFORT INTO THIS, AND I DO NOT WANT THIS TO BE DISTRIBUTED ELSEWHERE FOR FREE. THANK YOU!


In this model you shall find:


- Eye Movement example for Gaze Script
	- LookHorizontal Anim + LookVertical Anim + Blink Anim
	- Code Snippet for Gaze in myscript.lua 
	- Modelparts for Gaze functionality (sclera, iris, eyelid, eyebrow)


- PhysBone example for PhysBone Script
	- Four physBone Tassels (ripped from my Jester) with boneEnds
	- Example of physBone instructions in myscript.lua
		- physBone instructions will vary for each tassel, so you can see how different instructions make physBones behave differently.


- Example of how Model Part Rotation works (and how it can be stopped)
	- Head folder is renamed to 'NonRotHead' in order to prevent Minecraft/Figura from recognising 'Head' and applying regular instructions to it.


- Minecraft Pivot Points 
	- Armour Pivots
	- Elytra Pivots
	- Parrot Sitting Position Pivots
	- Spyglass Position Pivots
	- Left/Right Hand Item Pivots


- Basic Action Wheel Example
	- Toggle Action Example
	- Regular Action Example
	- Multi-Page Functionality


- Arms and Legs split into folders for movement at the joints
	- These joints will work with any of my custom walk/movement animations (like my skipping animation)


- WalkGuide Cubes (to be used with dynamic_speed script) + Custom walk cycle anims + math
	- A separate walkguide.bbmodel will be provided in the Useful Scripts zip
	- This model contains examples of custom walk and sprint cycles, and the additional math anims that dynamic_speed.lua uses to calculate the speed


- Custom animations
	- There are multiple examples of animations and the keyframes they need. For these animations to be recognised and to play in game, USE EZANIMS SCRIPT!!!	
	- There is an example of how to make an animation that plays when you are stopping another. For instance, when you stop crouching.
		- This animation is called crouch_outro. The _outro is the part that makes the animation play when the 'crouch' anim has stopped. This relies on the EZAnim.lua script!


- Example of how MoarArmsAPI works
	- The model has 4 arms total, and custom instructions in myscript.lua for the MoarArmsAPI script to follow
	- The instructions in myscript.lua vary slightly to showcase how different values affect the arms


- Example of how GSAnimBlend works + how it is used for custom animations
	- GSAnimBlend works best when used alongside EZAnims, as EZAnims has inbuilt compatibility with it
	- You can also make GSAnimBlend detect your custom animations. This is shown in myscript.lua


- Example of my LookDir + DiveFold/Flap Snippet
	- Lookdir is what I used to make my wings rotate according to my look direction when flying
	- My DiveFold/Flap code snippet is what I wrote in order to make my wings flap when going up, and fold in when going down.
	- There is an example of how these two code snippets can be used in myscript.lua


- Example of Instruction Keyframes
	- In elytra related animations, there are examples of how instruction keyframes work. These ones specifically showcase how you can use instruction keyframes to spawn in particles.
	- In the crouch animation, there is an example of how instruction keyframes can be used to play sounds.
	- There are instruction keyframes that play sound and particles in the sprint animation

- Example of footstep sound replacement 
	- Code snippet included for replacing what sound plays when the regular footstep sound is detected. You can also play particles and such here.


- Example of visually replacing an in-game item with a custom designed item
	- A separate model, named 'wrench' will appear in place of any item with the 'sword' NBT tag in game
	- Code snippet for this included in myscript.lua
	




