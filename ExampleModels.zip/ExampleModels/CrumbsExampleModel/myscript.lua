


-- This is the script in which you will write any of your own custom code. I'm going to include a couple of code snippets here beforehand that you will want to keep.
-- There is going to be a LOT of green writing here from me. This is because I will be assuming you know nothing about scripting prior to this, and I want to provide as much information as possible.
-- DO NOT FEEL THAT YOU MUST READ EVERYTHING. A LOT OF THIS WILL BE EXPLANATIONS FOR WHAT THINGS ARE / WHAT THINGS DO. YOU WONT NECESSARILY NEED AN EXPLANATION FOR EVERYTHING, A LOT IS SELF EXPLANATORY.




-- CODE SNIPPET #1: VANILLA MODEL VISIBILITY
    -- This is where you can make your regular vanilla model invisible. Currently, every part of the vanilla model is set to be invisible. If you want to keep certain parts visible by default, simply remove the
    -- necessary line of code (if you want your vanilla legs to be visible, delete or put -- before the lines 'vanilla_model.LEFT_LEG:setVisible(false)' and 'vanilla_model.RIGHT_LEG:setVisible(false)').
            vanilla_model.LEFT_ARM:setVisible(false)

            vanilla_model.RIGHT_ARM:setVisible(false)

            vanilla_model.LEFT_LEG:setVisible(false)

            vanilla_model.RIGHT_LEG:setVisible(false)

            vanilla_model.HEAD:setVisible(false)

            vanilla_model.BODY:setVisible(false)

            vanilla_model.ELYTRA:setVisible(false)

            vanilla_model.PLAYER:setVisible(false)          -- <- This will set your entire vanilla model to be invisible. It just does what the lines above it do, but in one single line of code. I have included
                                                                    -- the individual lines of code in the assumption that people may want to customise what is and is not visible by default. If you want
                                                                    -- more customisation over what is visible, use the -- to dash this line out.





                                                                    


 -- CODE SNIPPET #2: VOICECHAT MOD COMPATIBILITY 
    -- In your model, include an animation labeled 'talk' by default. You do not have to do anything with this animation, it can be any loop mode and doesn't have to have any keyframes.
    -- You only need the animation in order to prevent the script from erroring, as the code below will look for an animation named 'talk' in your blockbench model. If it doesn't find one, it errors.
    -- You will also need to swap out 'model' to whatever you have named your blockbench model. If your blockbench model file is still called 'model' then that is fine. Just don't change the code.
            local microphoneOffTime = 0
            local isMicrophoneOn = false

            function pings.talking(state)
                animations.examplemodel.talk:setPlaying(state)     -- <----- HERE IS WHERE YOU MAY NEED TO SWAP OUT THE WORD 'model' FOR YOUR BLOCKBENCH MODEL NAME!
            end

            function events.tick()
                local previousMicState = isMicrophoneOn

                microphoneOffTime = microphoneOffTime + 1
                isMicrophoneOn = microphoneOffTime <= 2 

                if previousMicState ~= isMicrophoneOn then
                    pings.talking(isMicrophoneOn)
                end
            end

            if client:isModLoaded("figurasvc") and host:isHost() then
                function events.HOST_MICROPHONE(pcm)
                    microphoneOffTime = 0
                end
            end






        
-- CODE SNIPPET #3: ACTION WHEEL

        local anims = require("EZAnims")   -- YOU WILL WANT THE EZANIMS SCRIPT DOWNLOADED TOO. YOU JUST WILL. YOU ALWAYS WILL. ALSO JUST LEAVE THESE 3 LINES PLEASE
        local customAnimPlaying = nil
        local animToRestart = nil

-- PAGES SECTION
        -- This is where you can make a custom Action Wheel. I have already included code (mostly written by people other than myself) as an example. I will help explain what it all does.
        -- This section specifically is where you can add pages to your action wheel. 

            local mainPage = action_wheel:newPage()    -- this is where you add more pages
            local secondPage = action_wheel:newPage()

            action_wheel:setPage(mainPage)    -- this is where you say what the default page is

            local toSecond = mainPage:newAction()       -- this is where you create actions that let you click between pages IN GAME.
                :title("Secondary Page Example")
                :item("minecraft:stick")
                :onLeftClick(function()
                log("Swapped to the second page")
                action_wheel:setPage(secondPage)
            end)

            local toMain = secondPage:newAction()
                :title("Main Page Example")
                :item("minecraft:grass_block")
                :onLeftClick(function()
                log("Swapped to the main page")
                action_wheel:setPage(mainPage)
                end)

        -- If you want to add another page, you would add 'local thirdPage = action_wheel:newPage()' under the line 'local secondPage = action_wheel:newPage'
            -- Then, you would add this:
                    -- local toThird = secondPage:newAction()
                        -- :title("Third Page Example")
                        -- :item("minecraft:furnace")           <-- This can be whatever block you want.
                        -- :onLeftClick(function()              <-- This says that it will activate upon being left-clicked
                        -- log ("Swapped to the third page")    <-- This is just a log function to show you in in-game chat that it worked
                        -- action_wheel:setPage(thirdPage)      <-- This is what it is told to do upon being clicked. In this case, it sets the page to be the third page.





-- PING FUNCTIONS SECTION 
    --('PINGS' ALLOW OTHER PLAYERS TO SEE THE ACTION YOU CLICKED. THESE PINGS ALSO DEFINE WHAT THAT ACTION *IS*.)

        -- PING FUNCTION EXAMPLE #1: Normal Easy Action
                    -- This is generally how an action is formatted. You would put whatever you want to happen inside the function here. Each new function/action should have its own unique name.
                function pings.exampleActionClicked()
                    print("Hello World! If I was an animation that had been told to play, I would be playing now!")
                end

                function pings.exampleStopActionClicked()
                    print("Bye World! If I was an animation that had been told to play, I would stop now!")
                end




        -- PING FUNCTION EXAMPLE #2: Toggle Action
                    -- This action will allow you to toggle something on/off. You can make an action function as a toggle in different ways too, but this is how the ACTUAL toggle action looks.
                    -- Currently this toggle will just turn the examplemodels extra arms visible and invisible.

                function pings.toggling(state)
                    models.examplemodel.root.LeftArm2:setVisible(state)
                    models.examplemodel.root.RightArm2:setVisible(state)
                    -- animation toggle example (commented out to avoid erroring):
                    -- animations.bbmodelname.animationname:setPlaying(state)
                end




        -- PING FUNCTION EXAMPLE #3: Anim Stop + Restart Action
                    --This action will stop an animation, 'nameOfAnimationToStop',  from playing when 'nameOfAnimationToPlay' is playing, and then restart 'nameOfAnimationToStop' when 'nameOfAnimationToPlay' is done.
                    -- For example, I use this with my Jester Dance animation. I pause my 'idle' animation while 'jesterdance' is playing, and then restart 'idle' when 'jesterdance' is over.
                
                -- function pings.nameOfThisActionActionClicked()
                --    animations.model.nameOfAnimationToPlay:play()
                --    animations.model.nameOfAnimationToStop:stop()
                --    if customAnimPlaying ~= nil then customAnimPlaying:stop()
                --    customAnimPlaying = animations.model.nameOfAnimationToPlay
                --    animToRestart = animations.model.nameOfAnimationToStop
                --end

                    -- Here is what my jesterdance example looked like. (NOTE: you would replace 'model' with whatever you named your model file in Blockbench):

                    -- function pings.jesterActionClicked()                     <--- This defines what action just got clicked. In this case, I called it the jesterActionClicked.
                        -- animations.model.jesterdance:play()                  <--- This part tells Figura what to do when that action gets clicked. AKA, what animation to play.
                        -- animations.model.idle:stop()                         <--- These next 4 lines are part of the code my Dad wrote. This one tells it to stop playing the idle animation when I play 'jesterdance'. 
                        -- if customAnimPlaying ~= nil then customAnimPlaying:stop() end    
                        -- customAnimPlaying = animations.model.jesterdance
                        -- animToRestart = animations.model.idle                <--- This tells it to restart the idle animation once the jesterdance animation has stopped playing.
                    -- end




-- ACTIONS SECTION
        -- This is where you actually create the 'action' on the action wheel - AKA the button to click on in game.
        -- These actions will play the ping functions you write above. Each function will need its own action down here.
        -- To make a new action, just copy the one below and customise it accordingly. The only thing you will need to make sure you change is which ping function the action activate.


                local action = mainPage:newAction()          -- <-- This is where you specify what PAGE you want it to appear on.
                    :title("Example")
                    :item("minecraft:stick")
                    :hoverColor(1, 0, 1)
                    :onLeftClick(pings.exampleActionClicked)       -- <-- Specifies which ping function this action will activate when clicked.
                    :onRightClick(pings.exampleStopActionClicked)


                -- This is the respective action for the toggle ping function above. 
                local toggleAction = secondPage:newAction()
                    :setToggled(true)              -- <-- If you want the toggle to be ON by default, INCLUDE this line of code.
                    :title("Extra Arms are Off")
                    :toggleTitle("Extra Arms are On")
                    :item("red_wool")
                    :toggleItem("green_wool")
                    :setOnToggle(pings.toggling)








-- CUSTOMANIMPLAYING HANDLING + FUNCTIONALITY FOR EZANIMS SCRIPT. LEAVE THIS BIT ALONE PLEASE

                    local function getInfo()
                            if customAnimPlaying ~= nil then
                            if not customAnimPlaying:isPlaying() then
                                animToRestart:play()
                                customAnimPlaying = nil
                            end
                        end
                    end

                    function events.tick()
                        getInfo()
                    end


-- ANY ADDITIONAL / NEW CODE (THAT IS UNRELATED TO CODE SNIPPETS ABOVE) SHOULD GO BELOW HERE!







-- GAZE CODE SNIPPET

-- GAZE | Credit to bitslayn (Fox) on Figura Discord
local gaze = require("Gaze")

local mainGaze = gaze:newGaze()                                                  -- Create a new gaze. We don't provide any arguments as the head is in-line with our camera
mainGaze:newAnim(animations.examplemodel.LookHorizontal, animations.examplemodel.LookVertical) -- We will create a newAnim here in this example, providing the animations we just created
mainGaze:newBlink(animations.examplemodel.Blink) 



-- PHYSBONE CODE SNIPPET
-- TO SEE PHYSBONES IN GAME, CLICK SHIFT AND ` AT THE SAME TIME. THE ` KEY IS THE ONE UNDER THE ESC KEY ON YOUR KEYBOARD. THIS IS JUST FOR REFERENCE.

local physBone = require('physBoneAPI')
function events.entity_init()           -- <-- ALL PHYSBONE INSTRUCTION GOES WITHIN THIS FUNCTION!

physBone.physBone_L_Front_Tassel:setGravity(-20):setBounce(0.1):setNodeRadius(0.5)
physBone.physBone_L_Back_Tassel:setBounce(0.1):setAirResistance(0.8):setMass(0.2)

physBone.physBone_R_Front_Tassel:setGravity(-20):setAirResistance(0.8):setNodeRadius(1):setSimSpeed(0.8)
physBone.physBone_R_Back_Tassel:setGravity(-20):setBounce(0.1):setAirResistance(0.8):setNodeRadius(0.5)        -- <-- This one is straight ripped from my Jester, so this is an example of how HIS tassels work.

end


-- GS ANIMBLEND SNIPPET

local GSAnimBlend = require('GSAnimBlend') 

animations.examplemodel.crouch:setBlendTime(2, 0)
animations.examplemodel.crouch_outro:setBlendTime(0, 0)




-- LOOPING ANIMS FOR OVERRIDES
animations.examplemodel.elytraoverride:play()






-- MOAR ARMS CODE SNIPPET
    -- WHATEVER YOU DO: DO NOT PUT MOARARMS INTO A TICK EVENT. DO NOT. EVER. PUT. MOARARMS. INTO A TICK EVENT. EVER.
    -- ALSO, THIS IS NOT TYPICALLY HOW YOU WILL DO MOARARMS. YOU WILL USUALLY REGISTER THE VANILLA ARMS AS NEWARMS TOO. I DIDN'T HERE BECAUSE I DIDN'T WANT THE VANILLA ONES TO MOVE DURING SPECIFIC ANIMS.
    -- I WILL COMMENT OUT WHAT THE CODE FOR THE VANILLA ARMS WOULD NORMALLY LOOK LIKE!
Arm = require("MOARArmsAPI")

--Arm:newArm(id, side, item pivot, arm model, held slot, anim options, custom animations)
    --VanillaLeftArm = Arm:newArm(1, "LEFT", models.examplemodel.root.LeftArm.L_forearm.LeftItemPivot, models.examplemodel.root.LeftArm, "OFFHAND")
    --VanillaRightArm = Arm:newArm(1, "RIGHT", models.examplemodel.root.RightArm.R_forearm.RightItemPivot, models.examplemodel.root.RightArm, "MAINHAND")

    ExtraLeftArm = Arm:newArm(2, "RIGHT", models.examplemodel.root.LeftArm2.L_forearm2.LeftItemPivot2, models.examplemodel.root.LeftArm2, nil, {WALK=0.5, IDLE=0})        
    ExtraRightArm = Arm:newArm(2, "LEFT", models.examplemodel.root.RightArm2.R_forearm2.RightItemPivot2, models.examplemodel.root.RightArm2, nil, {WALK=1, IDLE=0, SWING=0})
    -- ^^ The reason these two arms are registered as the opposite (left arm being registered as "RIGHT" and right arm being registered as "LEFT") is so that when they swing they do not hit the arm in front of them.
        -- ^^ The reason you need to DO this is because "RIGHT" and "LEFT" refer to the models **legs**, so they track how the legs move, not how the arms move.
        -- The reason they track the legs rather than the arms is so that they swing opposite to the respective leg. Not sure why it is done quite the way it is, but oh well.





-- LOOKDIR CODE SNIPPET (WING TILT BASED ON WHERE YOU'RE LOOKING + HOW FAST YOURE GOING)
    -- This is a code snippet I found and modified in order to allow for wings (elytra) to tilt when you turn in the air! This will also work for other modelparts + for other circumstances.
    -- For example, you can make your model's arms bend when walking. 
    -- You should include an else statement (doesn't have to be elseif, usually the elseif is so you can specify ANOTHER requirement) where you include the same bits of code above, but with the values set back to 0.
        -- ONE MORE NOTE: For this to work smoothly, make sure your modelpart **CUBES** are rotated how you want them to be, and that the folders they are in have no rotation. 
        -- When resetting back to 0, it will reset the original blockbench folder rotation back to zero, so if previously the folder was rotated by 10 in blockbench, it will display as 0 rotation.

    function events.tick()
    local Velocity = -player:getVelocity()
        local Dir = player:getLookDir()
        local DirAndVecX = (Velocity * Dir) * 40
        local DirAndVecZ = ((-Velocity[1] * Dir[3]) * 40) + ((Velocity[3] * Dir[1]) * 40)
        local DirAndVecX = DirAndVecX[3] + DirAndVecX[1]

            if player:getPose() == "FALL_FLYING" then
                vanilla_model.HELD_ITEMS:setVisible(false)
                models.examplemodel.root:setRot(DirAndVecX * -0.5, 0, DirAndVecZ * -1)

                models.examplemodel.root.NonRotHead:setRot(DirAndVecX * 0.8, 0, DirAndVecZ * 1)
                models.examplemodel.root.LeftArm:setRot(DirAndVecX * 0.8, 0, DirAndVecZ * 1)
                models.examplemodel.root.RightArm:setRot(DirAndVecX * 0.8, 0, DirAndVecZ * 1)

                models.examplemodel.root.Elytra:setRot(DirAndVecX * 0.5, 0, DirAndVecZ * 1)
                models.examplemodel.root.Elytra.LeftElytra:setRot(DirAndVecX * -0.5, -10, DirAndVecZ * -2)
                models.examplemodel.root.Elytra.RightElytra:setRot(DirAndVecX * -0.5, 10, DirAndVecZ * -2)
                models.examplemodel.root.Elytra.LeftElytra.L_Cylinder1:setRot(DirAndVecX * -0.5, -5, DirAndVecZ * 2)
                models.examplemodel.root.Elytra.LeftElytra.L_Cylinder2:setRot(DirAndVecX * -0.5, -5, DirAndVecZ * 2)
                models.examplemodel.root.Elytra.RightElytra.R_Cylinder1:setRot(DirAndVecX * -0.5, 0, DirAndVecZ * 2)
                models.examplemodel.root.Elytra.RightElytra.R_Cylinder2:setRot(DirAndVecX * -0.5, 0, DirAndVecZ * 2)

                models.examplemodel.root.LeftLeg:setRot(DirAndVecX * 0.5, 0, DirAndVecZ * 2)
                models.examplemodel.root.RightLeg:setRot(DirAndVecX * 0.5, 0, DirAndVecZ * 2)


            elseif player:getPose() ~= "FALL_FLYING" then
                vanilla_model.HELD_ITEMS:setVisible(true)
                models.examplemodel.root:setRot(DirAndVecX * 0, 0, DirAndVecZ * 0)

                models.examplemodel.root.NonRotHead:setRot(DirAndVecX * 0, 0, DirAndVecZ * 0)
                models.examplemodel.root.LeftArm:setRot()
                models.examplemodel.root.RightArm:setRot()

                models.examplemodel.root.Elytra:setRot(DirAndVecX * 0, 0, DirAndVecZ * 0)
                models.examplemodel.root.Elytra.LeftElytra:setRot(DirAndVecX * 0, 0, DirAndVecZ * 0)
                models.examplemodel.root.Elytra.RightElytra:setRot(DirAndVecX * 0, 0, DirAndVecZ * 0)
                models.examplemodel.root.Elytra.LeftElytra.L_Cylinder1:setRot(DirAndVecX * 0, 0, DirAndVecZ * 0)
                models.examplemodel.root.Elytra.LeftElytra.L_Cylinder2:setRot(DirAndVecX * 0, 0, DirAndVecZ * 0)
                models.examplemodel.root.Elytra.RightElytra.R_Cylinder1:setRot(DirAndVecX * 0, 0, DirAndVecZ * 0)
                models.examplemodel.root.Elytra.RightElytra.R_Cylinder2:setRot(DirAndVecX * 0, 0, DirAndVecZ * 0)

                models.examplemodel.root.LeftLeg:setRot(DirAndVecX * 0, 0, DirAndVecZ * 0)
                models.examplemodel.root.RightLeg:setRot(DirAndVecX * 0, 0, DirAndVecZ * 0)



            end


    end



-- DIVEFOLD AND FLAP CODE SNIPPET (BY ME!)
    -- This bit of code relies on you having THREE animations for your wings: elytra, divefold, and flap. You do not need (and should not have) an elytradown animation.
    -- The way this works is by keeping the elytra animation playing the entire time when you're flying, even when divefold and flap play. 
    -- Since elytra will be playing while flap and divefold play, your flap and divefold animations will STACK on top of it. This will result in some funky looking animations in blockbench. 
    -- If you model your wings to rely on an animation for positioning (like how AH!Wilburs wings do) then the 'wingsnorm' animation section at the end is for you. I'll be commenting it out for this avatar.
        -- For this avatar specifically, my flap and divefold animations will purely be for instruction keyframes. 
        -- Usually the name of these would be quite self explanatory, flap would be a wing flap, divefold would be the wings folding inward to increase aerodynamics.


    local isGliding = false     
    function events.tick()
        --logTable(animations:getPlaying())
        --log(player:getRot())
        local isDiving = player:getRot().x >= 30    -- classify 'isDiving' as when the player's x value is rotated 30 degrees or more DOWNWARD. down is positive and up is negative in this. 
        if isGliding ~= isDiving and player:getPose() == "FALL_FLYING" then     -- 'isGliding ~= isDiving' checks for rotation being >= 30, player:getPose() =="FALL_FLYING" checks that you're using an elytra
            animations.examplemodel.divefold:play()
        
        else
            animations.examplemodel.divefold:stop()
            
        end

        local isRising = player:getRot().x <= -10   -- classify 'isRising' as when the player's x value is rotated -10 degrees or less UPWARD. the lower the value, the more upward you're angled. Usually this is -20.
        if isGliding ~= isRising and player:getPose() == "FALL_FLYING" then     -- 'isGliding ~= isRising' checks for rotation being <= -10, player:getPose() =="FALL_FLYING" checks that you're using an elytra
            animations.examplemodel.flap:play()
          
            animations.examplemodel.flap:setSpeed(player:getVelocity().xz:length()*2)   -- this bit determines how your velocity affects the speed at which the animation will play.
        else
            animations.examplemodel.flap:stop()
           
        end

        --if player:getPose() ~= "FALL_FLYING" then
            --animations.examplemodel.wingsnorm:play()
        --else
            --animations.examplemodel.wingsnorm:stop()
        --end
    end


-- DETECT WHEN USING FIREWORK (DURING FLIGHT) CODE SNIPPET FROM ME
function events.tick()
    if player:getHeldItem(true).id == "minecraft:firework_rocket" and player:isSwingingArm() and player:getPose() == "FALL_FLYING" then
        particles:newParticle("amendments:fireball_explosion_emitter", models.examplemodel.root.Elytra.RightElytra.R_Cylinder2.R_point2:partToWorldMatrix():apply())
    end
    if player:getHeldItem(false).id == "minecraft:firework_rocket" and player:isSwingingArm() and player:getPose() == "FALL_FLYING" then
        particles:newParticle("amendments:fireball_explosion_emitter", models.examplemodel.root.Elytra.RightElytra.R_Cylinder2.R_point2:partToWorldMatrix():apply())
    end
end


-- DETECT + REPLACE FOOTSTEP SOUND SNIPPET
    function events.ON_PLAY_SOUND(id, pos, vol, pitch, loop, category, path)
        if not path then return end -- don't trigger if the sound was played by figura (prevent infinite loop)
        if not player:isLoaded() then return end -- don't trigger if the player isn't loaded
        local nearest, uuid = math.huge -- we will find the nearest player to the sound location
        for _, plr in pairs(world.getPlayers()) do
            local dist = (plr:getPos() - pos):length()
            if dist < nearest then nearest,uuid = dist,plr:getUUID() end
        end
        if player:getUUID() ~= uuid or nearest > 0.8 then return end -- don't trigger if the sound isn't near you

        ---------------------------------------------------------
        -- actual replacing starts here, feel free to edit below:
        if id:find(".step")then                                                  -- if sound id contains ".step"
            sounds:playSound("minecraft:item.spyglass.use", player:getPos(), 0.01, 1)
            sounds:playSound("minecraft:block.piston.extend", player:getPos(), 0.03, 1.4)-- play a custom sound
            return true                                                           -- stop the actual step sound
        end
    end


-- CUSTOM ITEM RENDERING (Replacing an item visually in game)

    function events.item_render(item)
        if item.id:find('sword') then
        return models.wrench.Item 
        end
    end

